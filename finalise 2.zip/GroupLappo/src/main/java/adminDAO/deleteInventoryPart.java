package adminDAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class deleteInventoryPart {
	
	public boolean isPartUsed(int partID) {
	   
	    try {
	    	Class.forName("com.mysql.jdbc.Driver");
		    Connection con = DriverManager.getConnection(
		    "jdbc:mysql://localhost:3306/lappo2?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC", "root", "Zack1234!"); 

	    String sql = "SELECT COUNT(*) FROM repairpart WHERE PartID = ?;";
	    
	    PreparedStatement ps = con.prepareStatement(sql);
	    ps.setInt(1, partID);

        ResultSet rs = ps.executeQuery();
        
        if (rs.next()) {
        	 return rs.getInt(1) > 0;
        }
        
	}catch (Exception e) {
        e.printStackTrace();
    }
	    return true;
	}
	
	public boolean deletePart(int partID) {

	    try {
	    	Class.forName("com.mysql.jdbc.Driver");
		    Connection con = DriverManager.getConnection(
		    "jdbc:mysql://localhost:3306/lappo2?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC", "root", "Zack1234!"); 
	    	
	    	  String sql = "DELETE FROM part WHERE PartID = ?";
	    	  
	    	  PreparedStatement ps = con.prepareStatement(sql);
	  	      ps.setInt(1, partID);

	  	    return ps.executeUpdate() > 0;
	    	
	    }catch (Exception e) {
	        e.printStackTrace();
	    }
	    return false;	         	
}
}
	    
	    
