<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.util.List" %>
<%@ page import="userModel.Repair" %>
<%@ page import="userModel.Student" %>
<%@ page import="userDAO.RepairDAO" %>

<%
    RepairDAO repairDAO = new RepairDAO();
%>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard - Lappo</title>
    <link rel="stylesheet" href="CSS/UserDashboard.css">
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    
   
        
       
</head>
<body>
<% String studentName = (String) session.getAttribute("username"); %>

    <div class="wrapper">
        
        <!-- SIDEBAR (Light Theme) -->
        <nav class="sidebar">
            <div class="sidebar-header">
                <i class="fas fa-laptop"></i> <span>Welcome <%= studentName %></span>
            </div>
            
            <div class="sidebar-nav">
                <a href="ongoingRepairs">
                    <i class="fas fa-th-large"></i> <span>Dashboard</span>
                </a>
               <a href="repairStatus">
                    <i class="fas fa-search-location"></i> <span>Track Repair</span>
                </a>
                <a href="pastInvoices">
                    <i class="fas fa-history"></i> <span>History</span>
                </a>
                <a href="Profile">
                    <i class="fas fa-user-circle"></i> <span>Profile</span>
                </a>
               
            </div>

            <div class="sidebar-footer">
                <button class="btn-logout" onclick="window.location.href='LoginPage.jsp'">
                    <i class="fas fa-sign-out-alt"></i> <span>Logout</span>
                </button>
            </div>
        </nav>

        <!-- MAIN CONTENT -->
        <main class="main-content">
            
            <!-- Header -->
            <header class="top-header">
                <div>
                    <h1>Welcome, <%= studentName %></h1>
                    <p>Here's what's happening with your devices today.</p>
                </div>
                <div class="user-profile" onclick="window.location.href='Profile'">
                    <i class="far fa-bell" style="font-size: 1.2em; color: var(--light-text-color); cursor: pointer;" onclick="event.stopPropagation()"></i>
                    <span><%= studentName %></span>
                    <div class="avatar-circle"><i class="fas fa-user"></i></div>
                </div>
            </header>

            <!-- Dashboard Statistics -->
            <div class="stats-grid">
                <!-- Active Repairs -->
                <div class="stat-card">
                    <div class="stat-info">
                        <h3>Active Repairs</h3>
                        <p class="number"><%= request.getAttribute("activeRepairs") %></p>
                    </div>
                    <div class="stat-icon icon-blue">
                        <i class="fas fa-tools"></i>
                    </div>
                </div>

                <!-- Total Repairs -->
                <div class="stat-card">
                    <div class="stat-info">
                        <h3>Total History</h3>
                        <p class="number"><%= request.getAttribute("totalRepairs") %></p>
                    </div>
                    <div class="stat-icon icon-teal">
                        <i class="fas fa-clipboard-check"></i>
                    </div>
                </div>

                <!-- Pending Payment -->
                <div class="stat-card">
                    <div class="stat-info">
                        <h3>Amount Paid</h3>
                        <p class="number">RM <%= String.format("%.2f", request.getAttribute("amountDue")) %></p>
                    </div>
                    <div class="stat-icon icon-orange">
                        <i class="fas fa-wallet"></i>
                    </div>
                </div>
            </div>

            <!-- Quick Action Bar -->
            <div class="action-bar">
                <button type="button" class="btn-action" onclick="openBookingModal()">
                    <i class="fas fa-plus"></i> Book New Repair
                </button>
            </div>

            <!-- Table: Current Repairs -->
            <div class="panel">
                <div class="panel-header">
                    <h2>Ongoing Repairs</h2>
                    <span class="badge badge-progress"><%= request.getAttribute("activeRepairs") %> Active</span>
                </div>
                
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Tracking ID</th>
                            <th>Date Submitted</th>
                            <th>Device</th>
                            <th>Issue</th>
                            <th>Status</th>
                            <th>Action</th>
                           
                        </tr>
                    </thead>
                    <tbody>
            			<%
               				// Get the list from the request
                			List<Repair> repairList = (List<Repair>) request.getAttribute("ongoingRepairList");
                			if (repairList != null) {
                    			for (Repair repair : repairList) {
            			%>
                			<tr>
                    			<td><%= repair.getRepairID() %></td>
                    			<td><%= repair.getDateIssued() %></td>
                    			<td><%= repair.getLaptopModel() %></td>
                    			<td><%= repair.getIssue() %></td>
                    			<td><%= repair.getCurrentStatus() %></td>
                    			<td>
                    		<% if ("Pending".equalsIgnoreCase(repair.getCurrentStatus())) { %>
                    			<button class="btn-sm btn-delete" onclick="confirmCancel('<%= repair.getRepairID() %>')">
                                        <Span>Cancel Booking</Span>
                                </button>
                			
                		
                			</td>	
                			<%} %>
                			</tr>
            			<%
                    			}
                			}
            			%>
        			</tbody>
                </table>
            </div>

            <!-- Table: Repair History -->
            <div class="panel">
                <div class="panel-header">
                    <h2>Past Repairs</h2>
                    <span class="badge badge-progress"><%= request.getAttribute("countPastRepair") %> Complete</span>
                </div>
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Device</th>
                            <th>Issue</th>
                            <th>Date Completed</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <%
                        	List<Repair> pastRepairList = (List<Repair>) request.getAttribute("pastRepair");
                        
                        	if (pastRepairList != null){
                        		for (Repair r : pastRepairList) {
                        %>
                        <tr>
                        	<td><%= r.getLaptopModel() %></td>
    						<td><%= r.getIssue() %></td>
    						<td><%= r.getDateIssued() %></td>
    						<td><%= r.getCurrentStatus() %></td>
                        </tr> 
                        <%			
                        }
                        }
                        %>
                    </tbody>
                </table>
            </div>

        </main>
    </div>
    
    <!-- Booking Modal Popup -->
    <div id="bookingModal" class="modal">
        <div class="modal-content">
            <span class="close-btn" onclick="closeBookingModal()">&times;</span>
            <h2 style="margin-top: 0; color: var(--text-color); margin-bottom: 20px;">Schedule Repair</h2>
            <form action="submitRepair" method="post">
                <div class="form-group">
                    <label>Device Model</label>
                    <input type="text" name="laptopModel" placeholder="e.g. MacBook Pro 2021" required>
                </div>
                
                <div class="form-group">
                    <label>Serial Number</label>
                    <input type="text" name="serialNumber" placeholder="e.g. 4CEGTF632FG" required>
                </div>
                
                <div class="form-group">
                    <label>Issue Type</label>
                    <select name="issue">
                        <option>Screen Damage</option>
                        <option>Battery Issue</option>
                        <option>Water Damage</option>
                        <option>Keyboard Issue</option>
                        <option>Touchpad</option>
                        <option>Overheating</option>
                        <option>Storage</option>
                        <option>Slow Performance</option>
                        <option>Software/OS</option>
                        <option>Other</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Description</label>
                    <textarea name="description" rows="3" placeholder="Please describe the issue..." required></textarea>
                </div>
                <div class="form-group">
                    <label>Preferred Date</label>
                    <input type="date" name="dateIssued" required>
                </div>
                <button type="submit" class="btn-submit">Confirm Booking</button>
            </form>
        </div>
    </div>

    <!-- Script to handle modal -->
    <script>
        // Simple and robust modal logic
        function openBookingModal() {
            var modal = document.getElementById("bookingModal");
            if (modal) {
                modal.style.display = "flex";
            }
        }
        
        function closeBookingModal() {
            var modal = document.getElementById("bookingModal");
            if (modal) {
                modal.style.display = "none";
            }
        }
        
        // Close modal when clicking outside
        window.onclick = function(event) {
            var modal = document.getElementById("bookingModal");
            if (event.target == modal) {
                modal.style.display = "none";
            }
        }
        
        function confirmCancel(id) {
            if (!confirm("Cancel booking For Booking ID " + id + "?")) return;

            fetch("CancelBooking", {
                method: "POST",
                headers: { "Content-Type": "application/x-www-form-urlencoded" },
                body: "repairID=" + encodeURIComponent(id)
            })
            .then(res => res.text())
            .then(msg => {
                msg = msg.trim();
                if (msg === "success") {
                    alert("Booking cancelled.");
                    location.reload();
                } else {
                    alert(msg);
                }
            })
            .catch(() => alert("Server error."));
        }


    </script>

</body>
</html>